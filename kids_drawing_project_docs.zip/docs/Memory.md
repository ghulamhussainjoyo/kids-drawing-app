# Project Memory — Kids Drawing App

This is durable project context for contributors and AI coding assistants. Update it when decisions change. Do not turn assumptions into confirmed requirements.

## 1. Vision
Build a commercial children's drawing and coloring app for iOS and Android. The differentiator is expressive freehand painting with reliable region-constrained coloring, not only tap-to-fill.

## 2. Confirmed constraints and decisions
- Prototype in both Flutter and React Native + Skia.
- Implement Flutter first, then reproduce the same scope in React Native + Skia.
- Choose the production framework only after fair real-device benchmarking.
- Do not choose React Native just because the product owner has RN experience.
- Flutter SDK is installed and the app launches.
- User works in Cursor and wants complete, practical file-level implementation guidance.
- Initial Dart files were created but are empty because implementation code had not yet been provided.
- Current pubspec uses Dart constraint `^3.13.7`, Flutter SDK, `cupertino_icons`, `flutter_test` and `flutter_lints`. The first drawing milestone needs no third-party package.

## 3. Existing Flutter paths
```text
lib/
  main.dart
  home.page.dart
  features/
    drawing/presentation/drawing/
      drawing.canvas.dart
      drawing.toolbar.dart
      brush.selector.dart
      color.palette.dart
    models/
      drawing.stroke.dart
      drawing.layer.dart
      drawing.region.dart
      brush.config.dart
    state/drawing.controller.dart
    engine/
      stroke.renderer.dart
      canvas.engine.dart
      region.engine.dart
      export.engine.dart
      brush.engine.dart
      layer.manager.dart
```
Use these exact paths when providing code unless a refactor is agreed.

## 4. Requested capabilities
Pencil, marker, crayon, paintbrush, watercolor, airbrush/spray and eraser; smooth finger/stylus input; pressure/tilt where available; region selection and clipping; separate paint and outline layers; undo/redo; zoom/pan; stickers/backgrounds; high-resolution PNG export; offline-first operation.

## 5. Artwork requirements
Each independently paintable part needs a stable region ID and a closed vector path or equivalent mask. Decorative/open paths are non-paintable. Flattened PNG/JPG alone is not enough for accurate clipping. SVG is preferred when independent paths and stable IDs are preserved.

## 6. Figma reference
`https://www.figma.com/design/2XqvA9NcrDgQc6C6fTmIJM/kids-drawing-app?node-id=11-154&m=dev`
Inspected node `11:154`: landscape workspace, large central canvas, apple/books artwork, left editing/navigation controls, right-side color/tool controls, completion action upper-right and extra control lower-right. Visible scribbles raise the question of free-draw mode alongside region coloring. Only one screen has been inspected.

## 7. Agreed plan
1. Audit relevant Figma screens and interactions.
2. Agree shared prototype scope and benchmark scenarios.
3. Build Flutter prototype.
4. Build equivalent React Native + Skia prototype.
5. Test on same physical devices, OS versions, artwork and stroke sequences.
6. Compare drawing feel, clipping, latency, frame times, memory, CPU/GPU, export, heat and stability.
7. Select framework based on evidence, then build the full product.

## 8. Performance goals (not measured results)
At least 60 FPS on agreed baseline devices, 120 FPS where supported, aim under 20 ms input-to-visible latency, no visible clipping bleed, and no unbounded memory growth during long sessions. Profile release builds on physical devices.

## 9. Current status
- Flutter setup and app launch: complete.
- Documentation: initial baseline being added.
- Drawing Dart files: exist but are empty.
- `find assets -maxdepth 3 -type f` run from `lib` returned no files. This does not prove the project-root assets directory is empty; inspect the correct location.
- Drawing engine: not implemented.
- Framework benchmark: not started.

## 10. AI/developer working rules
Read the project docs before substantial changes. Inspect files before overwriting. Preserve existing paths. Provide complete code, not references to code never supplied. Avoid unnecessary dependencies. Work in runnable milestones. Do not claim performance targets are met without measurements. Keep both prototypes behaviorally aligned. Record decisions and unresolved questions here.
