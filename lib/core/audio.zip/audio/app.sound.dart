import 'dart:math';

import 'package:flutter/widgets.dart';
import 'package:flutter_soloud/flutter_soloud.dart';
import 'package:kids_drawing_flutter/core/audio/ambience.player.dart';
import 'package:kids_drawing_flutter/core/audio/music.player.dart';
import 'package:kids_drawing_flutter/core/audio/sfx.player.dart';
import 'package:kids_drawing_flutter/core/audio/sound.assets.dart';
import 'package:kids_drawing_flutter/core/audio/touch.haptics.dart';
import 'package:kids_drawing_flutter/core/audio/voice.clips.dart';
import 'package:kids_drawing_flutter/core/audio/voice.lines.dart';
import 'package:kids_drawing_flutter/types/category.model.dart';
import 'package:kids_drawing_flutter/types/genre/genre.model.dart';
import 'package:kids_drawing_flutter/types/tools/stationary.model.dart';

/// Everything the app asks for by sound, in one place.
///
/// Screens and ViewModels call these methods; which player and which
/// settings toggle is involved is decided here, so no caller has to know.
class AppSound with WidgetsBindingObserver {
  final SfxPlayer sfx;
  final MusicPlayer music;
  final AmbiencePlayer ambience;
  final VoiceClips clips;
  final VoiceLines lines;
  final TouchHaptics haptics;

  AppSound({
    required this.sfx,
    required this.music,
    required this.ambience,
    required this.clips,
    required this.lines,
    required this.haptics,
  });

  /// Built with the one SoLoud engine the whole app shares.
  factory AppSound.create() {
    final soloud = SoLoud.instance;
    final sfx = SfxPlayer(soloud);
    return AppSound(
      sfx: sfx,
      music: MusicPlayer(soloud),
      ambience: AmbiencePlayer(sfx),
      clips: VoiceClips(soloud),
      lines: VoiceLines(),
      haptics: TouchHaptics(),
    );
  }

  /// Taps and stroke sounds sit a little below full, so a voice line on top
  /// of them is still the clearest thing in the room.
  static const _sfxVolume = 0.8;

  /// Two requests for the same click this close together are one click.
  static const _repeatWindow = Duration(milliseconds: 150);

  final Map<String, DateTime> _playedAt = {};

  bool _musicOn = true;
  bool _voiceOn = true;
  bool _sfxOn = true;
  bool _muted = true;
  String _trackId = 'puppy_playtime';
  String _language = '';
  int _speechGeneration = 0;

  final Random _random = Random();

  /// Which line of a pool was used last, so the next one is different.
  final Map<String, int> _lastPick = {};

  Future<void> load() async {
    try {
      await SoLoud.instance.init();
    } catch (_) {
      // No audio device: every clip will report itself missing and the app
      // runs silently rather than failing to start.
    }
    await sfx.warmUp(SoundAssets.uiSounds);
    WidgetsBinding.instance.addObserver(this);
  }

  Future<void> applyPreferences({
    required bool musicOn,
    required bool voiceOn,
    required bool sfxOn,
    required bool vibrationOn,
    required double volume,
    required String trackId,
    required String language,
  }) async {
    final sfxJustTurnedOn = sfxOn && !_sfxOn;
    _voiceOn = voiceOn;
    _sfxOn = sfxOn;
    _musicOn = musicOn;
    _trackId = trackId;

    haptics.setEnabled(vibrationOn);
    music.setVolume(volume);
    ambience.setVolume(volume);

    if (!sfxOn) {
      await sfx.stopLoop();
    }
    if (!voiceOn) {
      await clips.stop();
      music.unduck();
    }
    // The volume slider calls this on every drag frame, so only touch the
    // engine and the translation pack when the language really changed.
    if (_language != language) {
      _language = language;
      await lines.setLanguage(language);
      await clips.setLanguage(language);
    }
    await ambience.setEnabled(musicOn);
    await music.setEnabled(musicOn);
    await _retrackMusic();

    // Switching effects back on should be audible straight away.
    if (sfxJustTurnedOn) {
      await sfx.play(SoundAssets.tapIn, volume: _sfxVolume);
    }
  }

  // ---------------------------------------------------------------- buttons

  /// Going somewhere: a screen opened, something was picked.
  void pressIn() {
    _playPress(SoundAssets.tapIn);
  }

  /// Leaving: back, close, cancel.
  void pressOut() {
    _playPress(SoundAssets.tapOut);
  }

  void _playPress(String path) {
    if (_repeated(path)) {
      return;
    }
    haptics.tap();
    if (!_sfxOn) {
      return;
    }
    sfx.play(path, volume: _sfxVolume);
  }

  /// A back button and the route it pops both ask for the leaving sound, so
  /// the second one inside the window is dropped.
  bool _repeated(String path) {
    final now = DateTime.now();
    final last = _playedAt[path];
    _playedAt[path] = now;
    return last != null && now.difference(last) < _repeatWindow;
  }

  // ------------------------------------------------------------- background

  /// Splash and the genre hub: the app's own music, no genre ambience.
  Future<void> playAppMusic() async {
    ambience.stop();
    await music.playTrack(_trackId);
  }

  /// A genre was picked: its ambience clips take over from the music.
  Future<void> genreOpened(GenreModel genre) async {
    haptics.select();
    if (_sfxOn) {
      sfx.play(SoundAssets.selectBell, volume: _sfxVolume);
    }
    _speakPool('genre.${genre.id}', genre.voice);
    await music.stop();
    ambience.start(genre.ambience);
  }

  /// The canvas belongs to the drawing sounds alone.
  Future<void> canvasOpened() async {
    ambience.pause();
    await music.stop();
  }

  /// Back out of the canvas into the genre's gallery.
  void genreResumed() {
    ambience.resume();
  }

  // ------------------------------------------------------------- selections

  void artworkOpened({required String key, required String text}) {
    _speak('artwork.$key', text);
  }

  void categorySelected(CategoryModel category) {
    _speakPool('category.${category.name}', category.voice);
  }

  void toolSelected(CategoryModel category, StationaryModel tool) {
    haptics.select();
    if (_sfxOn) {
      sfx.play(SoundAssets.toolSelect, volume: _sfxVolume);
    }
    _speak('tool.${category.name}.${tool.name}', tool.spokenName);
    // The next stroke should not wait for its sound to decode.
    sfx.preload(SoundAssets.drawPath(category.drawSound));
  }

  // ----------------------------------------------------------------- stroke

  void strokeBegan(CategoryModel category, Offset point) {
    haptics.strokeBegan(point);
    if (!_sfxOn) {
      return;
    }
    final path = SoundAssets.drawPath(category.drawSound);
    if (category.loopSound) {
      sfx.startLoop(path, volume: _sfxVolume);
      return;
    }
    sfx.play(path, volume: _sfxVolume);
  }

  void strokeMoved(Offset point) {
    haptics.strokeMoved(point);
  }

  void strokeEnded({required bool committed}) {
    haptics.strokeEnded();
    sfx.stopLoop();
    if (committed && _sfxOn) {
      sfx.play(SoundAssets.burstPop, volume: _sfxVolume);
    }
  }

  void strokeCancelled() {
    haptics.strokeEnded();
    sfx.stopLoop();
  }

  // ---------------------------------------------------------------- plumbing

  /// One line out of a pool, never the same one twice running.
  Future<void> _speakPool(String key, List<String> pool) async {
    if (pool.isEmpty) {
      return;
    }
    final index = _pick(key, pool.length);
    await _speakLines({'$key.$index': pool[index]});
  }

  int _pick(String key, int count) {
    if (count < 2) {
      return 0;
    }
    final last = _lastPick[key];
    var index = _random.nextInt(count);
    if (index == last) {
      index = (index + 1) % count;
    }
    _lastPick[key] = index;
    return index;
  }

  Future<void> _speak(String key, String english) async {
    await _speakLines({key: english});
  }

  /// Says the lines in order and ducks the music for all of them.
  ///
  /// Each one is a recorded clip where we have it, and the device voice where
  /// we do not, so nothing is ever mute.
  Future<void> _speakLines(Map<String, String> script) async {
    if (!_voiceOn) {
      return;
    }
    final generation = ++_speechGeneration;
    music.duck();
    for (final entry in script.entries) {
      // A newer line started while this one was talking and owns the rest.
      if (generation != _speechGeneration) {
        return;
      }
      await _sayOne(lines.lineFor(entry.key, entry.value));
    }
    if (generation == _speechGeneration) {
      music.unduck();
    }
  }

  Future<void> _sayOne(String line) async {
    if (line.isEmpty) return;
    await clips.speak(line);
  }

  /// Follows a track change made in settings, but only where music belongs.
  Future<void> _retrackMusic() async {
    if (_muted || !_musicOn || !ambience.isIdle) {
      return;
    }
    await music.playTrack(_trackId);
  }

  /// Unmutes background music — called when the app reaches the main GenreScreen.
  Future<void> unmute() async {
    _muted = false;
    await _retrackMusic();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final leaving =
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached ||
        state == AppLifecycleState.hidden;
    if (leaving) {
      music.pause();
      ambience.pause();
      clips.stop();
      sfx.stopLoop();
      return;
    }
    if (state == AppLifecycleState.resumed) {
      music.resume();
      ambience.resume();
    }
  }

  Future<void> dispose() async {
    WidgetsBinding.instance.removeObserver(this);
    ambience.stop();
    await music.stop();
    await clips.dispose();
    await sfx.dispose();
  }
}
