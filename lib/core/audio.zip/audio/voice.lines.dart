import 'dart:convert';

import 'package:flutter/services.dart';

/// Optional per-language overrides for the spoken lines.
///
/// English lives on the models themselves, so there is no `en` pack to ship.
/// Dropping `assets/voice/ur.json` with `{"genre.school": "..."}` makes the
/// app speak Urdu without touching any Dart file.
class VoiceLines {
  Map<String, String> _lines = const {};

  /// Loads the pack for [languageCode] (e.g. `en_US`, `ur`). A missing pack
  /// is the normal case, not an error.
  Future<void> setLanguage(String languageCode) async {
    for (final name in _packNames(languageCode)) {
      final lines = await _loadPack(name);
      if (lines != null) {
        _lines = lines;
        return;
      }
    }
    _lines = const {};
  }

  /// The line to speak: the translated one when there is a pack for it,
  /// otherwise the English text authored on the model.
  String lineFor(String key, String english) {
    final translated = _lines[key];
    if (translated == null || translated.isEmpty) {
      return english;
    }
    return translated;
  }

  /// `en_US` looks for `en_us.json`, then `en.json`.
  List<String> _packNames(String languageCode) {
    final full = languageCode.toLowerCase().replaceAll('-', '_');
    final base = full.split('_').first;
    if (base == full) {
      return [full];
    }
    return [full, base];
  }

  Future<Map<String, String>?> _loadPack(String name) async {
    try {
      final raw = await rootBundle.loadString('assets/voice/$name.json');
      final decoded = jsonDecode(raw);
      if (decoded is! Map) {
        return null;
      }
      final lines = <String, String>{};
      decoded.forEach((key, value) {
        lines['$key'] = '$value';
      });
      return lines;
    } catch (_) {
      return null;
    }
  }
}
