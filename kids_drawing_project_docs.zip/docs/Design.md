# Design — Kids Drawing App

**Status:** Initial design baseline  
**Figma reference:** `kids-drawing-app`, node `11:154`. Only the referenced drawing screen has been inspected; this is not a complete Figma audit.

## 1. Design intent
A welcoming, child-friendly drawing experience where the canvas is the hero. Controls should be discoverable, forgiving and comfortable with fingers or stylus, while the painting tools remain expressive and high quality.

## 2. Principles
- Canvas first; maximize usable drawing area.
- Immediate visual response to touch.
- Clear selected brush, color and size.
- Large, forgiving controls and prominent undo.
- Accessible states that do not rely on color alone.
- Consistent behavior across iOS and Android.

## 3. Observed drawing workspace
The inspected Figma frame is landscape-oriented and shows:
- Large central white artwork canvas.
- Left-side navigation/editing controls, including undo/redo.
- Right-side color/tool area.
- Completion action near the upper-right.
- Additional drawing control near the lower-right.
- Apple and books artwork, with sample freehand marks around it.

Those sample marks suggest the product may need both region-constrained coloring and free-draw mode. Confirm this against the full design before locking behavior.

## 4. Screen hierarchy
**Drawing:** navigation/completion actions, main canvas, primary tools, color selection, brush size/opacity, secondary actions. Keep the canvas dominant.
**Home/library:** artwork thumbnails, categories, recent work and resume action.
**Export:** preview, save/export actions and clear permission/error feedback.

## 5. Interaction states
Every control defines default, selected, pressed, disabled and (where relevant) loading/error states. Brush/color/size changes apply to subsequent strokes; they must not mutate completed strokes.

## 6. Canvas modes
- **Region coloring:** select a paintable region, then draw with strokes clipped to it.
- **Free drawing:** draw anywhere without region clipping.
- **Pan/zoom:** use a clear gesture policy so navigation does not accidentally paint.

The active mode must be visible.

## 7. Child-friendly UX
Use large targets (aim for 44–48 logical pixels or larger for primary controls), simple labels/icons, clear undo, safe exit, short confirmations and readable contrast. Avoid flashing and distracting effects.

## 8. Responsive behavior
Support the agreed portrait/landscape layouts. Preserve artwork aspect ratio. On narrow screens, move secondary controls into a compact panel while keeping undo/redo accessible. Respect safe areas and avoid covering important artwork.

## 9. Visual tokens
Extract exact brand colors, typography, spacing, radii, shadows and icon styles from Figma variables/styles. Do not invent final brand values from one partial screenshot.

## 10. Open design questions
- Is region coloring or free drawing the default?
- Are visible scribbles artwork, tutorial hints or user strokes?
- Which controls remain visible in portrait?
- What does the completion action do?
- What age range and accessibility needs should be prioritized?
